import java.sql.*;

public class dbCnn1 {
    public static boolean checkUser(String username,String password) 
    {
        boolean st =false;
        try {
           
            Class.forName("org.h2.Driver");

                        Connection con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test/student1","sa","");
            PreparedStatement ps = con.prepareStatement("select * from REGISTRATION1  where username=? and password=?");
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs =ps.executeQuery();
            st = rs.next();

        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return st;                 
    }   
}

